# # * restaurants
 python ./train.py --seed 42 --max_span_size 8 --batch_size 16 --epochs 1 --dataset 14res


